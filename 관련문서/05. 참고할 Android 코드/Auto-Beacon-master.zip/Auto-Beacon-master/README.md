# Auto-Beacon
Open source beacon finder and macro executor



License : GNU GPL v3.0
